//JtreeLink plugin Language Settings
CKEDITOR.plugins.setLang('jtreelink','fr',
{
	jtreelink :
	{
		toolbar			: 'JTree Link\u200b',
		menu			: 'Modifier treeLink',
		title			: 'JTreeLink',
		info			: 'Infos lien',
		advanced		: 'Avanc&eacute;e',
		target			: 'Target',
		targetFrameName	: 'Nom du cadre cible',
		targetPopupName	: 'Nom Popup Window',
		targetFrame		: 'LightBox/<frame>',
		targetPopup		: '<fen&ecirc;tre popup>',
		targetFrameName	: 'Nom du cadre cible',
		targetPopupName	: 'Nom Popup Window',
		popupFeatures	: 'Caract&eacute;ristiques de la fen&ecirc;tre Popup',
		popupResizable	: 'Redimensionnable',
		popupStatusBar	: 'Barre d&eacute;tat',
		popupLocationBar: 'Location Bar',
		popupToolbar	: 'Barre doutils',
		popupMenuBar	: 'Barre de menu',
		popupFullScreen	: 'Plein &eacute;cran (IE)',
		popupScrollBars	: 'Barres de d&eacute;filement',
		popupDependent	: '&agrave; charge (Netscape)',
		popupWidth		: 'Largeur',
		popupLeft		: 'Position gauche',
		popupHeight		: 'Hauteur',
		popupTop		: 'Top Position',
		id				: 'Id',
		langDir			: 'Sens Langue',
		langDirLTR		: 'De gauche &agrave; droite (LTR)',
		langDirRTL		: 'De droite &agrave; gauche (RTL)',
		acccessKey		: 'Cl&eacute; dacc&egrave;s',
		name			: 'Nom',
		langCode		: 'Code de langue',
		tabIndex		: 'Tab Index',
		advisoryTitle	: 'Titre consultatif',
		advisoryContentType	: 'Type de contenu',
		cssClasses		: 'Classes de style',
		charset			: 'Charset ressource li&eacute;e',
		styles			: 'Style de'
	}
});

		